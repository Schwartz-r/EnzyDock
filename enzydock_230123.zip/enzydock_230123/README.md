# EnzyDock
EnzyDock: Protein–Ligand Docking of Multiple Reactive States along a Reaction Coordinate in Enzymes

For Python scripts to work, the location of a Python interpreter must be set
in the script scripts/python_wrapper.sh and the following Python libraries must be installed
in the Python environment used in python_wrapper.sh:

1) numpy
2) pandas
3) sklearn
4) kneed
5) openbabel
6) rdkit
7) pymol

This is easiest achieved using anaconda or miniconda

